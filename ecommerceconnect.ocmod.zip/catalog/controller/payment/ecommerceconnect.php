<?php
namespace Opencart\Catalog\Controller\Extension\Ecommerceconnect\Payment;

class Ecommerceconnect extends \Opencart\System\Engine\Controller
{
    private function setSession()
    {
        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');

        $rawSessionData = $this->session->data;

        $serializedSession = json_encode($rawSessionData);

        $this->log->write("Session Write::" . $serializedSession);

        try {
            $this->model_extension_ecommerceconnect_payment_ecommerceconnect->storeSession(array(
                'session_id' => $this->session->getId(),
                'session_data' => $serializedSession,
            ));
        } catch (Exception $e) {
            $this->log->write("db error" . $e->getMessage());
        }
    }

    private function getSession($sessionId): string
    {

        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');

        if ($this->session->getId() != $sessionId) {
            $sessionDataOnDB = $this->model_extension_ecommerceconnect_payment_ecommerceconnect->fetchSession($sessionId);
            $this->session->data = json_decode(($sessionDataOnDB['session_data']), true);
        }

        return $this->session->data['order_id'];
    }

    private function buildPaymentForm()
    {

        $totals = [];
        $taxes = $this->cart->getTaxes();
        $total = 0;

        $alpha_by_numeric = [
            '840' => 'USD',
            '978' => 'EUR',
            '980' => 'UAH',
            '977' => 'BAM',
            '348' => 'HUF',
            '975' => 'BGN',
            '941' => 'RSD',
            '008' => 'ALL',
        ];

        $this->load->model('checkout/cart');
        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');

        if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
            ($this->model_checkout_cart->getTotals)($totals, $taxes, $total);
        }

        $contract_numeric = ($this->config->get('payment_ecommerceconnect_currency') ? : 980);
        $alt_cfg_numeric = ($this->config->get('payment_ecommerceconnect_alt_currency') ? : 978);
        $contract_alpha = $alpha_by_numeric[$contract_numeric] ?? 'UAH';
        $alt_cfg_alpha = $alpha_by_numeric[$alt_cfg_numeric] ?? 'EUR';

        $session_code = (string)($this->session->data['currency'] ?? '');
        $this->load->model('checkout/order');
        $order = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        $order_total = (float)$order['total'];
        $order_code = (string)$order['currency_code'];
        $order_val = (float)$order['currency_value'];

        $src_code = $session_code ? : $order_code;

        $convert_from_order = function (float $amount, string $from_alpha, string $to_alpha) use ($order_val, $order): float {
            $from_val_now = (float)$this->currency->getValue($from_alpha);
            $to_val_now = (float)$this->currency->getValue($to_alpha);
            if ($order_val <= 0 || $from_val_now <= 0 || $to_val_now <= 0) {
                return $this->currency->convert($amount, $from_alpha, $to_alpha);
            }

            if ($from_alpha === (string)$order['currency_code']) {
                $base_at_order_time = $amount / $order_val;
            } else {
                $tmp_in_order = $this->currency->convert($amount, $from_alpha, (string)$order['currency_code']);
                $base_at_order_time = $tmp_in_order / $order_val;
            }

            return $base_at_order_time * $to_val_now;
        };

        $src_total = ($src_code === $order_code)
            ? $order_total
            : $convert_from_order($order_total, $order_code, $src_code);

        $total_amount = (int)round($convert_from_order($src_total, $src_code, $contract_alpha) * 100);

        if ($src_code === $contract_alpha) {
            $alt_currency_code = $contract_numeric;
            $alt_total_amount = $total_amount;
        } else {
            $alt_currency_code = $alt_cfg_numeric;
            $alt_total_amount = (int)round($convert_from_order($src_total, $src_code, $alt_cfg_alpha) * 100);
        }

        $locale = $this->config->get('payment_ecommerceconnect_lang') ?? 'ua';

        $purchaseTime = date("ymdHis");

        $formattedOrderId = str_pad($this->session->data['order_id'], 3, '0', STR_PAD_LEFT);

        $session = $this->session->getId();
        $order_id = $formattedOrderId;

        $merchant_id = $this->config->get('payment_ecommerceconnect_merchant_id_0');
        $terminal_id = $this->config->get('payment_ecommerceconnect_terminal_id_0');
        $delay = $this->config->get('payment_ecommerceconnect_pre_autorization') ? '1' : '0';

        $pem = $this->config->get('payment_ecommerceconnect_test_mode') ?
            $this->config->get('payment_ecommerceconnect_pem_test') :
            $this->config->get('payment_ecommerceconnect_pem_0');

        $data_str = "$merchant_id;$terminal_id;$purchaseTime;$order_id,$delay;$contract_numeric,$alt_currency_code;$total_amount,$alt_total_amount;$session;";

        $pkeyid = openssl_get_privatekey($pem);
        openssl_sign($data_str, $signature, $pkeyid, OPENSSL_ALGO_SHA512);
        unset($pkeyid);
        $b64sign = base64_encode($signature);

        //https://oc4.4web.pp.ua/index.php?route=extension/ecommerceconnect/payment/ecommerceconnect.callback
        $return_url = $this->url->link('extension/ecommerceconnect/payment/ecommerceconnect.callback', '', true);
        $cancel_url = $this->url->link('extension/ecommerceconnect/payment/ecommerceconnect.cancel&session=' . $this->session->getId(), '', true);

        $attributes = [
            "MerchantID" => $merchant_id,
            "TerminalID" => $terminal_id,
            "TotalAmount" => $total_amount,
            "AltTotalAmount" => $alt_total_amount,
            "Currency" => $contract_numeric,
            "AltCurrency" => $alt_currency_code,
            "Locale" => $locale,
            "PurchaseTime" => $purchaseTime,
            "OrderID" => $order_id,
            'Delay' => $delay,
            "SD" => $session,
            "Signature" => $b64sign,
        ];

        if ($this->customer->isLogged()) {
            $customer_id = $this->customer->getId();

            $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');
            $token = $this->model_extension_ecommerceconnect_payment_ecommerceconnect->getValidToken($customer_id);
            if ($token) {
                $attributes['UPCToken'] = $token;
            }
        }

        $data['attributes'] = $attributes;
        $data['logged'] = $this->customer->isLogged();
        $data['url'] = $this->config->get('payment_ecommerceconnect_url_0') . '/go/pay';

        $data['text_title'] = $this->config->get('payment_ecommerceconnect_title') ?? $this->language->get('heading_title');
        $data['text_description'] = $this->config->get('payment_ecommerceconnect_description') ?? $this->language->get('text_description');
        $this->setSession();

        return $this->load->view('extension/ecommerceconnect/payment/ecommerceconnect', $data);
    }

    /**
     * Callback
     *
     * @return view
     */
    private function handlePaymentResponse()
    {
        if (!isset($_POST) || empty($_POST)) {
            exit;
        }

        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');
        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');
        $this->load->model('checkout/order');

        $SD = $this->request->post['SD'] ?? '';
        $this->getSession($SD);

        $failedURL = $this->url->link(
            'extension/ecommerceconnect/payment/ecommerceconnect.forward',
            'sd=' . rawurlencode((string)$SD) . '&t=failure',
            true
        );

        $forwardUrl = $failedURL;

        if (!isset($this->session->data['order_id'])) {
            $this->log->write("Order was not found in session");

            exit();
        }

        $cert = $this->config->get('payment_ecommerceconnect_test_mode') ?
            $this->config->get('payment_ecommerceconnect_cert_test') :
            $this->config->get('payment_ecommerceconnect_cert_0');

        $MerchantID = $this->request->post['MerchantID'] ?? '';
        $TerminalID = $this->request->post['TerminalID'] ?? '';
        $OrderID = $this->request->post['OrderID'] ?? '';
        $Delay = $this->request->post['Delay'] ?? '';
        $PurchaseTime = $this->request->post['PurchaseTime'] ?? '';
        $TotalAmount = $this->request->post['TotalAmount'] ?? '';
        $AltTotalAmount = $this->request->post['AltTotalAmount'] ?? '';
        $AltCurrency = $this->request->post['AltCurrency'] ?? '';
        $CurrencyID = $this->request->post['Currency'] ?? '';
        $XID = $this->request->post['XID'] ?? '';
        $TranCode = $this->request->post['TranCode'] ?? '';
        $ApprovalCode = $this->request->post['ApprovalCode'] ?? '';

        $upcToken = $this->request->post['UPCToken'] ?? null;
        $upcTokenExp = $this->request->post['UPCTokenExp'] ?? null;

        $data = sprintf(
            '%s;%s;%s;%s,%s;%s;%s,%s;%s,%s;%s;%s;%s;%s%s',
            $MerchantID,
            $TerminalID,
            $PurchaseTime,
            $OrderID,
            $Delay,
            $XID,
            $CurrencyID,
            $AltCurrency,
            $TotalAmount,
            $AltTotalAmount,
            $SD,
            $TranCode,
            $ApprovalCode,
            $upcToken ?? '',
            $upcTokenExp ? ',' . $upcTokenExp . ';' : ''
        );

        $publicKey = openssl_pkey_get_public($cert);
        $decodedSignature = base64_decode($this->request->post["Signature"], true);
        $ok = openssl_verify($data, $decodedSignature, $publicKey, OPENSSL_ALGO_SHA512);

        $this->log->write("signature ok: " . $ok);
        //$this->log->write($this->request->post);

        if ($ok === 1) {

            $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');

            if ($Delay === '1') {
                //payment hold
                $this->model_checkout_order->addHistory(
                    $this->session->data['order_id'],
                    $this->config->get('payment_ecommerceconnect_hold_status_id'),
                    'UPC Pre-authorization successful',
                    true
                );

                $meta = [
                    'purchase_time' => $this->request->post['PurchaseTime'] ?? '',
                    'approval_code' => $this->request->post['ApprovalCode'] ?? '',
                    'rrn' => $this->request->post['Rrn'] ?? '',
                    'signature' => $this->request->post['Signature'] ?? '',
                    'upc_total_amount' => $TotalAmount ?? '',
                ];

                $this->model_extension_ecommerceconnect_payment_ecommerceconnect->savePreauthMeta($this->session->data['order_id'], $meta);
            } else {
                //payment accepted
                $this->model_checkout_order->addHistory(
                    $this->session->data['order_id'],
                    $this->config->get('payment_ecommerceconnect_approved_status_id'),
                    'UPC Payment Successful',
                    true
                );
            }

            $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

            if ($upcToken && $upcTokenExp && (int)($order_info['customer_id'] ?? 0) > 0) {
                $expires = $this->normalizeUpcDate($upcTokenExp);
                if ($expires) {
                    $this->model_extension_ecommerceconnect_payment_ecommerceconnect->setToken((int)$order_info['customer_id'], $upcToken, $expires);
                }
            }

            $forwardUrl = $this->url->link(
                'extension/ecommerceconnect/payment/ecommerceconnect.forward',
                'sd=' . rawurlencode((string)$SD) . '&t=success',
                true
            );
        } else if ($ok === 0) {
            //payment failed
            $this->log->write("payment fail other reason");
            $this->model_checkout_order->addHistory(
                $this->session->data['order_id'],
                $this->config->get('payment_ecommerceconnect_failed_status_id'),
                '',
                true
            );
        } else {
            //bad signature
            $this->log->write("signaure mismatch");
            $this->model_extension_ecommerceconnect_payment_ecommerceconnect->log("Error signature did not match");
        }

        print
            "MerchantID=" . $MerchantID . "\n" .
            "TerminalID=" . $TerminalID . "\n" .
            "OrderID=" . $OrderID . "\n" .
            "Currency=" . $CurrencyID . "\n" .
            "TotalAmount=" . $TotalAmount . "\n" .
            "XID=" . $XID . "\n" .
            "TranCode = " . $TranCode . "\n" .
            "PurchaseTime=" . $PurchaseTime . "\n\n" .
            "Response.action=approve\n" .
            "Response.reason=OK\n" .
            "Response.forwardUrl=" . $forwardUrl . "\n";

        exit();
    }

    public function index(): string
    {
        return $this->buildPaymentForm();
    }

    public function callback(): string
    {
        return $this->handlePaymentResponse();
    }

    public function cancel(): string
    {
        $this->getSession($_GET['session']);
        $this->log->write("Cancel returned, session restored to " . $_GET['session']);
        $redirect = $this->url->link('checkout/cart', 'language=' . $this->config->get('config_language'), true);

        return $this->response->redirect($redirect);
    }

    public function confirm(): void
    {
        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');

        $json = [];

        if (!isset($this->session->data['order_id'])) {
            $json['error']['warning'] = $this->language->get('error_order');
        }

        if (!isset($this->session->data['payment_method']) || $this->session->data['payment_method'] != 'ecommerceconnect') {
            $json['error']['warning'] = $this->language->get('error_payment_method');
        }

        if (!$json) {

            if ($this->config->get('payment_ecommerceconnect_response')) {

                $this->load->model('checkout/order');

                $this->model_checkout_order->addHistory($this->session->data['order_id'], $this->config->get('payment_ecommerceconnect_approved_status_id'), '', true);

                $json['redirect'] = $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true);
            } else {
                $this->load->model('checkout/order');

                $this->model_checkout_order->addHistory($this->session->data['order_id'], $this->config->get('payment_ecommerceconnect_failed_status_id'), '', true);

                $json['redirect'] = $this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true);
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Нормалізує дату з формату MMYYYY (наприклад 122026) у формат Y-m-d
     *
     * @param string $rawDate
     *
     * @return string|null
     */
    public function normalizeUpcDate(string $rawDate): ?string
    {
        $rawDate = trim($rawDate);

        if (!preg_match('/^\d{6}$/', $rawDate)) {
            return null;
        }

        $month = (int)substr($rawDate, 0, 2);
        $year = (int)substr($rawDate, 2, 4);

        if ($month < 1 || $month > 12) {
            return null;
        }

        try {
            $date = new \DateTime();
            $date->setDate($year, $month, 1);
            $date->modify('last day of this month');

            return $date->format('Y-m-d');
        } catch (\Exception $e) {
            return null;
        }
    }

    public function forward(): void
    {
        $sd = (string)($this->request->get['sd'] ?? '');
        $t = (string)($this->request->get['t'] ?? 'failure');

        if ($sd !== '') {
            $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');
            $row = $this->model_extension_ecommerceconnect_payment_ecommerceconnect->fetchSession($sd);

            if (!empty($row['session_data'])) {
                $session_data = json_decode($row['session_data'], true);
                $this->session->data = $session_data;

                if (!empty($session_data['customer_id'])) {
                    $this->load->model('account/customer');
                    $customer_info = $this->model_account_customer->getCustomer($session_data['customer_id']);

                    if ($customer_info) {
                        $this->customer->login($customer_info['email'], '', true);
                    }
                }
                $this->model_extension_ecommerceconnect_payment_ecommerceconnect->deleteSession($sd);
            }
        }
        if ($t === 'success') {
            $this->cart->clear();
        }

        $route = ($t === 'success') ? 'checkout/success' : 'checkout/failure';

        $this->response->redirect(
            $this->url->link($route, 'language=' . $this->config->get('config_language'), true)
        );
    }
}
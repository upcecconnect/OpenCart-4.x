<?php
// Heading
$_['heading_title'] = 'Оплата eCommerceConnect';

// Text
$_['text_title'] = 'Оплата eCommerceConnect';
$_['text_description'] = 'Оплата за допомогою eCommerceConnect (дебетові/кредитні картки)';

//Error gateway payment
$_['error_signature'] = 'Помилка: Відповідь шлюзу має недійсний підпис!';
<?php
// Heading
$_['heading_title'] = 'eCommerceConnect Payment';

// Text
$_['text_title'] = 'eCommerceConnect Payment';
$_['text_description'] = 'Pay with eCommerceConnect (Debit/Credit Cards)';

//Error gateway payment
$_['error_signature'] = 'Error: Gateway response have invalid signature!';
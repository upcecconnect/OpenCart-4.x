<?php
// Heading
$_['heading_title'] = 'eCommerceConnect Payment Gateway';

// Text
$_['ecommerceconnect_logo'] = '<a href="https://ecconnect.upc.ua" target="_blank"><img src="../extension/ecommerceconnect/admin/view/image/payment/ecommerceconnect.png" alt="eCommerceConnect" title="eCommerceConnect" style="border: 1px solid #EEEEEE;" /></a>';
$_['ecommerceconnect_description'] = 'Payment Gateway for Opencart 4. Accept credit and debit card payments from buyers worldwide with our payment system.';

$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified eCommerceConnect Payment Gateway API settings';
$_['text_edit'] = 'Edit eCommerceConnect Payment Gateway';
$_['text_approve'] = 'Approve';
$_['text_deny'] = 'Deny';

$_['entry_title'] = 'Title';
$_['entry_description'] = 'Description';
$_['entry_merchant_id'] = "Merchant ID";
$_['entry_terminal_id'] = "Terminal ID";
$_['entry_url'] = "Gateway URL";
$_['entry_pem'] = "Merchant's Private Key";
$_['entry_pem_test'] = "Merchant's Private Key for Test Mode";
$_['entry_cert'] = "Gateway Certificate";
$_['entry_cert_test'] = "Gateway Certificate for Test Mode";
$_['entry_test_mode'] = "Enable Test Mode";
$_['entry_pre_autorization'] = "Pre-authorization";

$_['entry_approved_status'] = 'Approved Status';
$_['entry_declined_status'] = 'Declined Status';
$_['entry_geo_zone'] = 'Geo Zone';
$_['entry_language'] = 'Language';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['entry_debug'] = 'Enable Debug Log';

$_['error_permission'] = 'Warning: You do not have permission to modify eCommerceConnect Payment Gateway';
$_['error_warning'] = 'Warning.';

$_['error_pem_format'] = 'Invalid private key format (PEM).';
$_['error_cert_format'] = 'Invalid certificate format.';
$_['text_success'] = 'Settings saved.';

$_['text_pem_saved'] = 'The value has been saved in the system. Leave the field empty if you do not want to change it.';
$_['text_pem_required'] = 'Required field.';
$_['required'] = 'Required field.';
$_['title_description'] = 'This controls the title which the user sees during checkout.';
$_['description_comment'] = 'This controls the description which the user sees during checkout';
$_['url_comment'] = 'e.g. https://ecg.test.upc.ua or https://secure.upc.ua';
$_['terminal_comment'] = 'This is the Terminal ID, received from eCommerceConnect';
$_['merchant_comment'] = 'This is the Merchant ID, received from eCommerceConnect';
$_['pem_comment'] = 'This is the Private key, received from eCommerceConnect';
$_['pem_comment_test'] = 'This is the Private key for test mode, received from eCommerceConnect';
$_['cert_comment'] = 'This is the Work certificate for signature verification from UPC e-Commerce Connect payment gateway';
$_['cert_comment_test'] = 'This is the Test certificate for signature verification from UPC e-Commerce Connect payment gateway';
$_['approved_status_comment'] = 'Set the current status of your OpenCart order for the corresponding transaction';
$_['failed_status_comment'] = 'Set the current status of your OpenCart order for the corresponding transaction';
$_['test_mod_comment'] = 'Place the payment gateway in test mode';
$_['status_comment'] = 'This controls whether or not this gateway is enabled within OpenCart.';
$_['debug_comment'] = 'Enable or disable logging';
$_['language_comment'] = 'Set the payment gateway language';
$_['pre_autorization_comment'] = 'For pre-authorization, check the checkbox';

$_['text_capture_box_title'] = 'Capture via UPC';
$_['text_capture_button'] = 'Capture';
$_['text_capture_amount'] = 'Capture Amount';
$_['text_capture_hint'] = 'Maximum amount: %s';
$_['text_loading'] = 'Loading…';
$_['error_permission'] = 'You do not have permission to modify this module.';

$_['entry_contract_currency'] = 'Transaction Currency (for UPC)';
$_['help_contract_currency'] = 'Currency to be sent to UPC payment (usually UAH).';
$_['entry_alt_currency'] = 'Alternative Currency (AltCurrency)';
$_['help_alt_currency'] = 'For alternative currency on the payment page: EUR or USD.';
$_['current_currency_by_default'] = 'Current default currency in OpenCart:';
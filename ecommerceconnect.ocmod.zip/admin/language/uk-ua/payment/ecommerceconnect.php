<?php
// Heading
$_['heading_title'] = 'Платіжний шлюз eCommerceConnect';

// Text
$_['ecommerceconnect_logo'] = '<a href="https://ecconnect.upc.ua" target="_blank"><img src="../extension/ecommerceconnect/admin/view/image/payment/ecommerceconnect.png" alt="eCommerceConnect" title="eCommerceConnect" style="border: 1px solid #EEEEEE;" /></a>';
$_['ecommerceconnect_description'] = 'Платіжний шлюз для Opencart 4. Приймайте оплати банківськими картками Visa та MasterCard з усього світу через нашу платіжну систему.';

$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Успіх: Ви змінили налаштування API платіжного шлюзу eCommerceConnect';
$_['text_edit'] = 'Редагування платіжного шлюзу eCommerceConnect';
$_['text_approve'] = 'Підтвердити';
$_['text_deny'] = 'Відхилити';

$_['entry_title'] = 'Заголовок';
$_['entry_description'] = 'Опис';
$_['entry_merchant_id'] = "Merchant ID";
$_['entry_terminal_id'] = "Terminal ID";
$_['entry_url'] = "URL шлюзу";
$_['entry_pem'] = "Приватний ключ продавця";
$_['entry_pem_test'] = "Приватний ключ продавця (тестовий режим)";
$_['entry_cert'] = "Сертифікат шлюзу";
$_['entry_cert_test'] = "Сертифікат шлюзу (тестовий режим)";
$_['entry_test_mode'] = "Увімкнути тестовий режим";
$_['entry_pre_autorization'] = "Преавторизація";

$_['entry_approved_status'] = 'Статус підтвердження';
$_['entry_declined_status'] = 'Статус відхилення';
$_['entry_geo_zone'] = 'Геозона';
$_['entry_language'] = 'Мова';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';
$_['entry_debug'] = 'Увімкнути журнал відладки';

$_['error_permission'] = 'Увага: У вас немає прав на зміну налаштувань eCommerceConnect Payment Gateway';
$_['error_warning'] = 'Попередження.';

$_['error_pem_format'] = 'Невірний формат приватного ключа (PEM).';
$_['error_cert_format'] = 'Невірний формат сертифіката.';
$_['text_success'] = 'Налаштування збережено.';

$_['text_pem_saved'] = 'Значення збережене в системі. Залиште поле порожнім, якщо не хочете змінювати.';
$_['text_pem_required'] = 'Обовʼязкове поле.';
$_['required'] = 'Обовʼязкове поле.';
$_['title_description'] = 'Це керує заголовком, який користувач бачить під час оформлення замовлення.';
$_['description_comment'] = 'Це керує описом, який користувач бачить під час оформлення замовлення';
$_['url_comment'] = 'Наприклад: https://ecg.test.upc.ua або https://secure.upc.ua';
$_['terminal_comment'] = 'Це Terminal ID, отриманий від eCommerceConnect';
$_['merchant_comment'] = 'Це Merchant ID, отриманий від eCommerceConnect';
$_['pem_comment'] = 'Це приватний ключ, отриманий від eCommerceConnect';
$_['pem_comment_test'] = 'Це приватний ключ для тестового режиму, отриманий від eCommerceConnect';
$_['cert_comment'] = 'Це робочий сертифікат для перевірки підпису від платіжного шлюзу UPC e-Commerce Connect';
$_['cert_comment_test'] = 'Це тестовий сертифікат для перевірки підпису від платіжного шлюзу UPC e-Commerce Connect';
$_['approved_status_comment'] = 'Встановіть статус замовлення в OpenCart для відповідної транзакції';
$_['failed_status_comment'] = 'Встановіть статус замовлення в OpenCart для відповідної транзакції';
$_['test_mod_comment'] = 'Перевести платіжний шлюз у тестовий режим';
$_['status_comment'] = 'Визначає, чи увімкнено цей платіжний шлюз в OpenCart';
$_['debug_comment'] = 'Увімкнути або вимкнути журналювання';
$_['language_comment'] = 'Встановити мову платіжного шлюзу';
$_['pre_autorization_comment'] = 'Для преавторизації відмітьте чекбокс';

$_['text_capture_box_title'] = 'Списання (Capture) через UPC';
$_['text_capture_button'] = 'Списати';
$_['text_capture_amount'] = 'Сума для списання';
$_['text_capture_hint'] = 'Максимальна сума: %s';
$_['text_loading'] = 'Завантаження…';
$_['error_permission'] = 'У вас немає прав на зміну цього модуля.';

$_['entry_contract_currency'] = 'Валюта транзакції (для UPC)';
$_['help_contract_currency'] = 'Валюта, яка буде відправлена у платіж на UPC (найчастіше UAH).';
$_['entry_alt_currency'] = 'Альтернативна валюта (AltCurrency)';
$_['help_alt_currency'] = 'Для альтернативної валюти на платіжній сторінці: EUR або USD.';
$_['current_currency_by_default'] = 'Поточна валюта за замовчуванням в OpenCart:';

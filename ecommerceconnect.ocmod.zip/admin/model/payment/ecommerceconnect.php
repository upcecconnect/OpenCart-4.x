<?php
namespace Opencart\Admin\Model\Extension\Ecommerceconnect\Payment;

class Ecommerceconnect extends \Opencart\System\Engine\Model
{
    public function install()
    {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "ecommerceconnect_session`;");
        $this->createMissingTables();

        $this->load->model('setting/setting');
        $this->load->model('localisation/language');

        $languages = $this->model_localisation_language->getLanguages();
        $lang_ids = array_column($languages, 'language_id');

        $names = [
            'en-gb' => 'EcommerceConnect: Hold',
            'uk-ua' => 'EcommerceConnect: Утримання коштів',
        ];

        $hold_id = $this->ensureOrderStatus($names, $lang_ids);

        $this->model_setting_setting->editSetting('payment_ecommerceconnect', [
            'payment_ecommerceconnect_hold_status_id' => $hold_id,
        ]);

        $this->migrateOrderColumns();
    }

    public function uninstall()
    {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "ecommerceconnect_session`;");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "customer_upc_token`;");
    }

    public function createMissingTables()
    {

        $this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ecommerceconnect_session` (
			`ecommerceconnect_session_id` INT(11) NOT NULL AUTO_INCREMENT,
			`session_id` VARCHAR(255) NOT NULL,
			`session_data` TEXT,
			PRIMARY KEY (`ecommerceconnect_session_id`)
			) ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;
		");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "customer_upc_token` (
              `customer_id` INT UNSIGNED NOT NULL,
              `token`       VARBINARY(512) NOT NULL,
              `expires_at`  DATETIME NOT NULL,
              `updated_at`  DATETIME NOT NULL,
              PRIMARY KEY (`customer_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");
    }

    private function ensureOrderStatus(array $names, array $lang_ids): int
    {
        $searchName = reset($names);

        $query = $this->db->query("SELECT order_status_id FROM `" . DB_PREFIX . "order_status`
        WHERE name = '" . $this->db->escape($searchName) . "' LIMIT 1");

        if ($query->num_rows) {
            $order_status_id = (int)$query->row['order_status_id'];
        } else {
            $first_lang_id = (int)$lang_ids[0];
            $this->db->query("INSERT INTO `" . DB_PREFIX . "order_status`
            SET language_id = '" . $first_lang_id . "', name = '" . $this->db->escape($searchName) . "'");
            $order_status_id = (int)$this->db->getLastId();
        }

        foreach ($this->model_localisation_language->getLanguages() as $lang) {
            $language_id = (int)$lang['language_id'];
            $code = $lang['code'] ?? '';
            $name = $names[$code] ?? $searchName;

            $exists = $this->db->query("SELECT 1 FROM `" . DB_PREFIX . "order_status`
            WHERE order_status_id = '" . $order_status_id . "'
            AND language_id = '" . $language_id . "'")->num_rows;

            if ($exists) {
                $this->db->query("UPDATE `" . DB_PREFIX . "order_status`
                SET name = '" . $this->db->escape($name) . "'
                WHERE order_status_id = '" . $order_status_id . "'
                AND language_id = '" . $language_id . "'");
            } else {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "order_status`
                SET order_status_id = '" . $order_status_id . "',
                    language_id = '" . $language_id . "',
                    name = '" . $this->db->escape($name) . "'");
            }
        }

        return $order_status_id;
    }

    private function migrateOrderColumns(): void
    {
        $table = DB_PREFIX . 'order';

        $this->addColumnIfMissing($table, 'upc_purchase_time', "VARCHAR(14) NULL DEFAULT NULL");
        $this->addColumnIfMissing($table, 'upc_approval_code', "VARCHAR(16) NULL DEFAULT NULL");
        $this->addColumnIfMissing($table, 'upc_rrn', "VARCHAR(32) NULL DEFAULT NULL");
        $this->addColumnIfMissing($table, 'upc_signature', "TEXT NULL DEFAULT NULL");
        $this->addColumnIfMissing($table, 'upc_total_amount', "TEXT NULL DEFAULT NULL");
    }

    private function addColumnIfMissing(string $table, string $column, string $definition): void
    {
        $exists = $this->db->query("SHOW COLUMNS FROM `{$table}` LIKE '" . $this->db->escape($column) . "'");
        if (!$exists->num_rows) {
            $this->db->query("ALTER TABLE `{$table}` ADD `{$column}` {$definition}");
        }
    }

    public function getPreauthMeta(int $order_id): array
    {
        $q = $this->db->query("SELECT upc_purchase_time, upc_approval_code, upc_rrn, upc_signature, upc_total_amount
                           FROM `" . DB_PREFIX . "order`
                           WHERE order_id = '" . (int)$order_id . "' LIMIT 1");
        if (!$q->num_rows) {
            return [];
        }

        return [
            'purchase_time' => $q->row['upc_purchase_time'] ?? '',
            'approval_code' => $q->row['upc_approval_code'] ?? '',
            'rrn' => $q->row['upc_rrn'] ?? '',
            'signature' => $q->row['upc_signature'] ?? '',
            'upc_total_amount' => $q->row['upc_total_amount'] ?? '',
        ];
    }

    public function setToken(int $customer_id, string $token, string $expires_at): void
    {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "customer_upc_token`
        SET `customer_id` = '" . (int)$customer_id . "',
            `token`       = '" . $this->db->escape($token) . "',
            `expires_at`  = '" . $this->db->escape($expires_at) . "',
            `updated_at`  = NOW()
        ON DUPLICATE KEY UPDATE
            `token`      = VALUES(`token`),
            `expires_at` = VALUES(`expires_at`),
            `updated_at` = NOW()");
    }

    public function getToken(int $customer_id): ?array
    {
        $q = $this->db->query("SELECT `token`,`expires_at`,`updated_at`
                               FROM `" . DB_PREFIX . "customer_upc_token`
                               WHERE `customer_id` = '" . (int)$customer_id . "'
                               LIMIT 1");

        return $q->num_rows ? $q->row : null;
    }

    public function deleteToken(int $customer_id): void
    {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "customer_upc_token`
                          WHERE `customer_id` = '" . (int)$customer_id . "'");
    }

    public function getValidToken(int $customer_id): ?string
    {
        $q = $this->db->query("SELECT `token`, `expires_at`
                               FROM `" . DB_PREFIX . "customer_upc_token`
                               WHERE `customer_id` = '" . (int)$customer_id . "'
                               LIMIT 1");

        if (!$q->num_rows) {
            return null;
        }

        $token = (string)$q->row['token'];
        $expiresRaw = (string)$q->row['expires_at'];

        try {
            $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
            $exp = new \DateTimeImmutable($expiresRaw, new \DateTimeZone('UTC'));
        } catch (\Throwable $e) {
            $this->deleteToken($customer_id);

            return null;
        }

        if ($exp <= $now) {
            $this->deleteToken($customer_id);

            return null;
        }

        return $token;
    }
}

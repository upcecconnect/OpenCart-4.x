<?php
namespace Opencart\Admin\Controller\Extension\Ecommerceconnect\Payment;

class Ecommerceconnect extends \Opencart\System\Engine\Controller
{
    public function index(): void
    {

        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');

        $data['entry_pem'] = $this->language->get('entry_pem');
        $data['text_pem_saved'] = $this->language->get('text_pem_saved');
        $data['text_pem_required'] = $this->language->get('text_pem_required');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token']),
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment'),
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/ecommerceconnect/payment/ecommerceconnect', 'user_token=' . $this->session->data['user_token']),
        ];

        $data['save'] = $this->url->link('extension/ecommerceconnect/payment/ecommerceconnect|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

        //restore form with previous data
        $data['payment_ecommerceconnect_approved_status_id'] = $this->config->get('payment_ecommerceconnect_approved_status_id');
        $data['payment_ecommerceconnect_failed_status_id'] = $this->config->get('payment_ecommerceconnect_failed_status_id');
        $data['payment_ecommerceconnect_geo_zone_id'] = $this->config->get('payment_ecommerceconnect_geo_zone_id');
        $data['payment_ecommerceconnect_lang'] = $this->config->get('payment_ecommerceconnect_lang');
        $data['payment_ecommerceconnect_status'] = $this->config->get('payment_ecommerceconnect_status');
        $data['payment_ecommerceconnect_sort_order'] = $this->config->get('payment_ecommerceconnect_sort_order');

        $data['payment_ecommerceconnect_title'] = $this->config->get('payment_ecommerceconnect_title');
        $data['payment_ecommerceconnect_description'] = $this->config->get('payment_ecommerceconnect_description');

        $data['payment_ecommerceconnect_pem_0'] = $this->config->get('payment_ecommerceconnect_pem_0');
        $data['payment_ecommerceconnect_pem_test'] = $this->config->get('payment_ecommerceconnect_pem_test');
        $data['payment_ecommerceconnect_cert_0'] = $this->config->get('payment_ecommerceconnect_cert_0');
        $data['payment_ecommerceconnect_cert_test'] = $this->config->get('payment_ecommerceconnect_cert_test');
        $data['has_pem'] = (bool)$this->config->get('payment_ecommerceconnect_pem_0');
        $data['has_pem_test'] = (bool)$this->config->get('payment_ecommerceconnect_pem_test');
        $data['has_cert'] = (bool)$this->config->get('payment_ecommerceconnect_cert_0');
        $data['has_cert_test'] = (bool)$this->config->get('payment_ecommerceconnect_cert_test');

        $data['payment_ecommerceconnect_url_0'] = $this->config->get('payment_ecommerceconnect_url_0');
        $data['payment_ecommerceconnect_merchant_id_0'] = $this->config->get('payment_ecommerceconnect_merchant_id_0');
        $data['payment_ecommerceconnect_terminal_id_0'] = $this->config->get('payment_ecommerceconnect_terminal_id_0');

        $data['payment_ecommerceconnect_pre_autorization'] = $this->config->get('payment_ecommerceconnect_pre_autorization');
        $data['payment_ecommerceconnect_debug'] = $this->config->get('payment_ecommerceconnect_debug');
        $data['payment_ecommerceconnect_test_mode'] = $this->config->get('payment_ecommerceconnect_test_mode');

        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $this->load->model('localisation/geo_zone');
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        $data['ecommerceconnect_languages'] = [
            'en' => 'English (default)',
            'uk' => 'Ukrainian (UAH)',
            'sr' => 'Serbian (RSD)',
            'hu' => 'Hungarian (HUF)',
            'bg' => 'Bulgarian (BGN)',
            'sq' => 'Albanian (ALL)',
            'bs' => 'Bosnian (BAM)',
            'de' => 'German (EUR)',
        ];

        $data['currency_options'] = [
            '840' => 'USD',
            '978' => 'EUR',
            '980' => 'UAH',
            '977' => 'BAM',
            '348' => 'HUF',
            '975' => 'BGN',
            '941' => 'RSD',
            '008' => 'ALL',
        ];

        $data['payment_ecommerceconnect_currency'] = ($this->config->get('payment_ecommerceconnect_currency') ? : 980);
        $data['payment_ecommerceconnect_alt_currency'] = ($this->config->get('payment_ecommerceconnect_alt_currency') ? : 978);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $default_currency_code = $this->config->get('config_currency');

        $this->load->model('localisation/currency');
        $currency_info = $this->model_localisation_currency->getCurrencyByCode($default_currency_code);

        $data['default_currency_code'] = $default_currency_code;
        $data['default_currency_title'] = $currency_info ? $currency_info['title'] : $default_currency_code;

        $this->response->setOutput($this->load->view('extension/ecommerceconnect/payment/ecommerceconnect', $data));
    }

    public function save(): void
    {
        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');

        $json = [];

        $allowed_contract = ['840', '978', '980', '977', '348', '975', '941', '008'];
        $allowed_alt = [840, 978];

        if (!$this->user->hasPermission('modify', 'extension/ecommerceconnect/payment/ecommerceconnect')) {
            $json['error']['warning'] = $this->language->get('error_permission');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));

            return;
        }

        $data = $this->request->post;

        if (!empty($data['payment_ecommerceconnect_pem_0']) &&
            !preg_match('/^-----BEGIN PRIVATE KEY-----[\s\S]+-----END PRIVATE KEY-----$/', $data['payment_ecommerceconnect_pem_0'])) {
            $json['error']['payment_ecommerceconnect_pem_0'] = $this->language->get('error_pem_format') ? : 'Invalid private key format.';
        }
        if (!empty($data['payment_ecommerceconnect_pem_test']) &&
            !preg_match('/^-----BEGIN PRIVATE KEY-----[\s\S]+-----END PRIVATE KEY-----$/', $data['payment_ecommerceconnect_pem_test'])) {
            $json['error']['payment_ecommerceconnect_pem_test'] = $this->language->get('error_pem_format') ? : 'Invalid private key format.';
        }
        if (!empty($data['payment_ecommerceconnect_cert_0']) &&
            !preg_match('/^-----BEGIN CERTIFICATE-----[\s\S]+-----END CERTIFICATE-----$/', $data['payment_ecommerceconnect_cert_0'])) {
            $json['error']['payment_ecommerceconnect_cert_0'] = $this->language->get('error_cert_format') ? : 'Invalid certificate format.';
        }
        if (!empty($data['payment_ecommerceconnect_cert_test']) &&
            !preg_match('/^-----BEGIN CERTIFICATE-----[\s\S]+-----END CERTIFICATE-----$/', $data['payment_ecommerceconnect_cert_test'])) {
            $json['error']['payment_ecommerceconnect_cert_test'] = $this->language->get('error_cert_format') ? : 'Invalid certificate format.';
        }

        if (isset($data['payment_ecommerceconnect_currency']) &&
            !in_array((int)$data['payment_ecommerceconnect_currency'], $allowed_contract, true)) {
            $data['payment_ecommerceconnect_currency'] = 980;
        }
        if (isset($data['payment_ecommerceconnect_alt_currency']) &&
            !in_array((int)$data['payment_ecommerceconnect_alt_currency'], $allowed_alt, true)) {
            $data['payment_ecommerceconnect_alt_currency'] = 978;
        }

        if (!empty($json['error'])) {
            $json['error']['warning'] = $this->language->get('error_warning');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));

            return;
        }

        $this->load->model('setting/setting');

        $current = $this->model_setting_setting->getSetting('payment_ecommerceconnect');

        $sensitive = [
            'payment_ecommerceconnect_pem_0',
            'payment_ecommerceconnect_cert_0',
            'payment_ecommerceconnect_pem_test',
            'payment_ecommerceconnect_cert_test',
        ];

        $merged = $current;

        $nonSensitive = [
            'payment_ecommerceconnect_title',
            'payment_ecommerceconnect_description',
            'payment_ecommerceconnect_merchant_id_0',
            'payment_ecommerceconnect_terminal_id_0',
            'payment_ecommerceconnect_url_0',
            'payment_ecommerceconnect_approved_status_id',
            'payment_ecommerceconnect_failed_status_id',
            'payment_ecommerceconnect_geo_zone_id',
            'payment_ecommerceconnect_status',
            'payment_ecommerceconnect_sort_order',
            'payment_ecommerceconnect_debug',
            'payment_ecommerceconnect_test_mode',
            'payment_ecommerceconnect_lang',
            'payment_ecommerceconnect_pre_autorization',
            'payment_ecommerceconnect_currency',
            'payment_ecommerceconnect_alt_currency',
        ];
        foreach ($nonSensitive as $k) {
            if (array_key_exists($k, $data)) {
                $merged[$k] = $data[$k];
            }
        }

        foreach ($sensitive as $k) {
            if (array_key_exists($k, $data) && $data[$k] !== '') {
                $merged[$k] = $data[$k];
            }
        }

        $this->model_setting_setting->editSetting('payment_ecommerceconnect', $merged);

        $json['success'] = $this->language->get('text_success') ? : 'Settings saved.';
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void
    {
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('ecommerceconnect_capture');

        if (VERSION >= '4.0.2.0') {
            $action_order_info = 'extension/ecommerceconnect/payment/ecommerceconnect.order_info';
            $action_order_form = 'extension/ecommerceconnect/payment/ecommerceconnect.order_form';
        } else {
            $action_order_info = 'extension/ecommerceconnect/payment/ecommerceconnect|order_info';
            $action_order_form = 'extension/ecommerceconnect/payment/ecommerceconnect|order_form';
        }

        $this->model_setting_event->addEvent([
            'code' => 'ecommerceconnect_capture',
            'description' => 'Inject capture form into admin order view',
            'trigger' => 'admin/view/sale/order_info/before',
            'action' => $action_order_info,
            'status' => 1,
            'sort_order' => 1,
        ]);

        $this->model_setting_event->addEvent([
            'code' => 'ecommerceconnect_capture',
            'description' => 'Inject capture form into admin order view/edit',
            'trigger' => 'admin/view/sale/order_form/before',
            'action' => $action_order_form,
            'status' => 1,
            'sort_order' => 2,
        ]);

        $this->load->model('setting/setting');
        $setting = $this->model_setting_setting->getSetting('config');
        $setting['config_session_samesite'] = 'Lax';
        $this->model_setting_setting->editSetting('config', $setting);

        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');
        $this->model_extension_ecommerceconnect_payment_ecommerceconnect->install();
    }

    public function uninstall(): void
    {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('ecommerceconnect_capture');

        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');
        $this->model_extension_ecommerceconnect_payment_ecommerceconnect->uninstall();
    }

    public function injectCaptureForm(string &$route, array &$args, string &$output): void
    {

        if (!isset($this->request->get['order_id'])) {
            return;
        }

        $order_id = (int)$this->request->get['order_id'];

        $this->load->model('sale/order');
        $order_info = $this->model_sale_order->getOrder($order_id);

        if (!$order_info) {
            return;
        }

        $method_code = $order_info['payment_method']['code'] ?? '';
        $hold_status_id = (int)$this->config->get('payment_ecommerceconnect_hold_status_id');

        if ($method_code !== 'ecommerceconnect.ecommerceconnect' || (int)$order_info['order_status_id'] !== $hold_status_id) {
            return;
        }

        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');
        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');

        $meta = $this->model_extension_ecommerceconnect_payment_ecommerceconnect->getPreauthMeta($order_id);

        $data = [];
        $data['order_id'] = $order_id;
        $data['max_amount'] = (float)$meta['upc_total_amount'] / 100;
        $data['action'] = $this->url->link(
            'extension/ecommerceconnect/payment/ecommerceconnect|capture',
            'user_token=' . $this->session->data['user_token'],
            true
        );

        $data['text_capture_box_title'] = $this->language->get('text_capture_box_title') ? : 'Capture via UPC';
        $data['text_capture_button'] = $this->language->get('text_capture_button') ? : 'Списати';
        $data['text_capture_amount'] = $this->language->get('text_capture_amount') ? : 'Сума для списання';
        $data['text_capture_hint'] = $this->language->get('text_capture_hint') ? : 'Макс.: %s';
        $data['text_loading'] = $this->language->get('text_loading') ? : 'Завантаження…';

        $html = $this->load->view('extension/ecommerceconnect/payment/capture_form', $data);

        $tabCapture['title'] = $this->language->get('text_capture_box_title');
        $tabCapture['code'] = 'ecommerceconnect_capture';
        $tabCapture['content'] = $html;

        $args['tabs'][] = $tabCapture;
    }

    public function capture(): void
    {

        $this->load->language('extension/ecommerceconnect/payment/ecommerceconnect');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/ecommerceconnect/payment/ecommerceconnect')) {
            $json['error']['warning'] = $this->language->get('error_permission') ? : 'Permission denied';
            $this->sendJson($json);

            return;
        }

        $order_id = (int)($this->request->post['order_id'] ?? 0);
        $amount = (float)($this->request->post['amount'] ?? 0);

        if ($order_id <= 0) {
            $json['error']['message'] = 'Order ID is missing';
            $this->sendJson($json);

            return;
        }
        if ($amount < 0.01) {
            $json['error']['message'] = 'Amount must be at least 0.01';
            $this->sendJson($json);

            return;
        }

        $this->load->model('sale/order');
        $order = $this->model_sale_order->getOrder($order_id);

        $this->load->model('extension/ecommerceconnect/payment/ecommerceconnect');

        $meta = $this->model_extension_ecommerceconnect_payment_ecommerceconnect->getPreauthMeta($order_id);

        if (!$order) {
            $json['error']['message'] = 'Order not found';
            $this->sendJson($json);

            return;
        }

        $hold_status_id = (int)$this->config->get('payment_ecommerceconnect_hold_status_id');
        if (($order['payment_method']['code'] ?? '') !== 'ecommerceconnect.ecommerceconnect' || (int)$order['order_status_id'] !== $hold_status_id) {
            $json['error']['message'] = 'Order is not eligible for capture';
            $this->sendJson($json);

            return;
        }

        $order_total = (float)$meta['upc_total_amount'] / 100;

        if ($amount > $order_total) {
            $json['error']['message'] = 'Amount cannot exceed order total: ' . $order_total;
            $this->sendJson($json);

            return;
        }

        $endpoint = rtrim((string)$this->config->get('payment_ecommerceconnect_url_0'), '/') . '/go/capture';
        $postData = [
            'MerchantID' => (string)$this->config->get('payment_ecommerceconnect_merchant_id_0'),
            'TerminalID' => (string)$this->config->get('payment_ecommerceconnect_terminal_id_0'),
            'OrderID' => $order_id,
            'Currency' => $this->config->get('payment_ecommerceconnect_currency'),
            'TotalAmount' => (int)$meta['upc_total_amount'],
            'PurchaseTime' => (string)$meta['purchase_time'],
            'ApprovalCode' => (string)$meta['approval_code'],
            'RRN' => (string)$meta['rrn'],
            'PostauthorizationAmount' => (int)round($amount * 100),
            'Signature' => (string)$meta['signature'],
        ];

        $body = null;
        $err = null;

        try {
            $ch = curl_init($endpoint);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
                CURLOPT_POSTFIELDS => http_build_query($postData),
                CURLOPT_CONNECTTIMEOUT => 15,
                CURLOPT_TIMEOUT => 30,
            ]);
            $body = curl_exec($ch);
            $err = curl_error($ch);
            curl_close($ch);
        } catch (\Throwable $e) {
            $err = $e->getMessage();
        }

        if ($err) {
            $json['error']['message'] = 'Capture request failed: ' . $err;
            $this->sendJson($json);

            return;
        }

        $parsed = $this->parseUpcResponse((string)$body);

        if (isset($parsed['TranCode']) && $parsed['TranCode'] === '000') {
            $approved_status_id = (int)$this->config->get('payment_ecommerceconnect_approved_status_id') ? : (int)$order['order_status_id'];

            $store_id = (int)($order['store_id'] ?? 0);
            $language = (string)($order['language_code'] ?? $this->config->get('config_language') ?? 'en-gb');
            $currency = (string)($order['currency_code'] ?? $this->config->get('config_currency') ?? 'USD');

            $this->request->get['user_token'] = $this->session->data['user_token'] ?? '';
            $this->request->get['call'] = 'history_add';
            $this->request->get['store_id'] = $store_id;
            $this->request->get['language'] = $language;
            $this->request->get['currency'] = $currency;
            $this->request->get['order_id'] = $order_id;

            $this->request->post = [
                'order_id' => $order_id,
                'order_status_id' => $approved_status_id,
                'override' => 0,
                'notify' => 1,
                'comment' => 'Captured via UPC Gateway',
            ];

            $jsonHistory = $this->load->controller('sale/order.call');

            $json['success'] = 'Capture success. Order moved to processing.';
            $this->sendJson($json);

            return;
        }

        $json['error']['message'] = 'Capture failed: ' . json_encode($parsed ? : ['raw' => $body]);
        $this->sendJson($json);
    }

    private function sendJson(array $payload): void
    {
        $this->response->addHeader('Content-Type: application/json; charset=utf-8');
        $this->response->setOutput(json_encode($payload));
    }

    private function parseUpcResponse(string $body): array
    {
        if (preg_match('/<p>(.*?)<\/p>/s', $body, $m)) {
            $lines = explode("\n", trim($m[1]));
            $parsed = [];
            foreach ($lines as $line) {
                if (strpos($line, '=') !== false) {
                    [$k, $v] = array_pad(explode('=', trim($line), 2), 2, '');
                    $parsed[trim($k)] = trim($v);
                }
            }

            return $parsed;
        }

        return [];
    }

    public function order_info(string &$route, array &$args, string &$output): void
    {
        $this->injectCaptureForm($route, $args, $output);
    }

    public function order_form(string &$route, array &$args, string &$output): void
    {
        $this->injectCaptureForm($route, $args, $output);
    }
}
